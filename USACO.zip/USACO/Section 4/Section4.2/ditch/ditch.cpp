/*
ID: huanshi
LANG: C++
TASK: ditch 
*/
#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
#include<vector>
#include<queue>
#include<algorithm>
#define INF 99999999
#define Max_Node 210
using namespace std;
FILE *fin,*fout;
struct Stream{//�����յ㣬����������߱�� 
	int to,cap,revNum;
};
vector<Stream>G[Max_Node];
int v[Max_Node][Max_Node];
int level[Max_Node];//���㵽Դ��ľ����� 
int iter[Max_Node];//��ǰ��������֮ǰ�ı߾�û������ 

void Add_Stream(int from,int to,int cap){
	G[from].push_back((Stream){to,cap,G[to].size()}); 
	G[to].push_back((Stream){from,0,G[from].size()-1});//����from�ող�����һ��������Ϊsize()-1 
} 
void bfs(int s){
	memset(level,-1,sizeof(level));
	queue<int> que;
	level[s]=0;
	que.push(s);
	while(!que.empty()){
		int v=que.front();que.pop();
		for(int i=0;i<G[v].size();i++){
			Stream &e=G[v][i];
			if(e.cap>0&&level[e.to]<0){
				level[e.to]=level[v]+1;
				que.push(e.to);
			}
		}
	}
} 
int dfs(int v,int t,int f){//��ǰ�㣬�յ�(����),��ǰ���� 
//	printf("%d ",v);
	if(v==t)return f;
	for(int &i=iter[v];i<G[v].size();i++){
		Stream &temp=G[v][i];
		if(temp.cap>0&&level[v]<level[temp.to]){
			int d=dfs(temp.to,t,min(f,temp.cap));
			if(d>0){
				temp.cap-=d;
				G[temp.to][temp.revNum].cap+=d;
				return d;
			}
		}
	}
	return 0; 
}
int max_flow(int s,int t){
	int flow=0;
	for(;;){
		bfs(s);
		if(level[t]<0)return flow;
		memset(iter,0,sizeof(iter));
		int f;
		while((f=dfs(s,t,INF))>0)flow+=f,printf("%d %d\n",f,flow); 
	}
}
int N,M;
int main(){
	fin=fopen("ditch.in","r");
	fout=fopen("ditch.out","w");
	fscanf(fin,"%d%d",&N,&M);
	int a,b,c;
	for(int i=0;i<N;i++){
		fscanf(fin,"%d%d%d",&a,&b,&c);
		if(!v[a][b]){
			v[a][b]=1;
			Add_Stream(a,b,c);
		}else{
			for(int i=0;i<G[a].size();i++)
			if(G[a][i].to==b)G[a][i].cap+=c; 
		}
	}
	fprintf(fout,"%d\n",max_flow(1,M));
	return 0;
}



