/*
ID: huanshi
LANG: C++
TASK: fence6
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int d[110][110],e[110][110];
int a[110],A[110];//��¼�߳��ͱߵ���ʼ�� 
int N,ccount=1;
bool hash[110][110];//�жϵ��Ƿ��¼
int ans=INF;
void init(){
	for(int i=1;i<110;i++)
		for(int j=1;j<110;j++)
			if(i!=j)d[i][j]=INF; 
}
void judge(int s[],int slength){//�жϵ��Ƿ��¼�����1��ʼ��ccount-1 
	int i,j,flag=0;
	for(i=1;i<ccount;i++){
		for(j=0;j<=slength;j++){
			if(!hash[i][s[j]])break;
		}
		if(j==slength+1)return ;
	}
	if(i==ccount){
		for(j=0;j<=slength;j++){
			hash[ccount][s[j]]=true;
			if(A[s[j]])d[A[s[j]]][ccount]=d[ccount][A[s[j]]]=s[j];//����ߵ���ʼ���Ѽ�¼������ 
			else A[s[j]]=ccount;//���δ��¼�򽫸õ���Ϊ��ʼ�� 
		}
		ccount++;
	}
}
int floyd(){
	for(int k=1;k<ccount;k++){
		for(int i=1;i<k;i++)
			for(int j=i+1;j<k;j++)
				ans=min(ans,d[i][j]+e[i][k]+e[k][j]);
		for(int i=1;i<ccount;i++){
			for(int j=1;j<ccount;j++){
				d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
			}
		}
	} 
	return ans;
} 
int main(){
	fin  = fopen ("fence6.in", "r");
    fout = fopen ("fence6.out", "w");
	fscanf(fin,"%d",&N);
	init();
	int s,Ls,Ns[2];
	for(int i=0;i<N;i++){
		fscanf(fin,"%d%d%d%d",&s,&Ls,&Ns[0],&Ns[1]);
		a[s]=Ls;
		int temp[10];
		temp[0]=s;
		for(int k=0;k<2;k++){
			for(int j=1;j<=Ns[k];j++){
				fscanf(fin,"%d",&temp[j]);
			}
			judge(temp,Ns[k]);
		}
	}
	for(int i=1;i<ccount;i++){//������ӱ�Ÿ�Ϊ���� 
		for(int j=1;j<ccount;j++){
			if(d[i][j]!=INF)d[i][j]=a[d[i][j]];
		} 
	}
	for(int i=1;i<ccount;i++){//�������� 
		for(int j=1;j<ccount;j++){
			e[i][j]=d[i][j];
		} 
	}
	floyd();
	for(int i=1;i<ccount;i++){
		for(int j=1;j<ccount;j++){
			printf("%d ",d[i][j]);
		}
		printf("\n"); 
	}
	fprintf(fout,"%d\n",ans);
	exit(0);
}

