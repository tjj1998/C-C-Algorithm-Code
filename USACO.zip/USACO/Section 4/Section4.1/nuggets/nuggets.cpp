/*
ID: huanshi
LANG: C++
TASK: nuggets
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int N,a[11];
bool v[66000];
typedef pair<int,int> P;

int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int main(){
	fin  = fopen ("nuggets.in", "r");
    fout = fopen ("nuggets.out", "w");
	fscanf(fin,"%d",&N);
	int temp=0;
	for(int i=0;i<N;i++){
		fscanf(fin,"%d",&a[i]);
		if(temp==0)temp=a[i];
		temp=gcd(a[i],temp);
	}
	if(temp>1)fprintf(fout,"%d\n",0); 
	else{
		sort(a,a+N);
		int Min=a[0];
		memset(v,0,sizeof(v));
		int temp=1,ccount=0,ans=0;
		v[0]=true;
		while(1){
			for(int i=0;i<N;i++){
				if(temp<a[i])break;
				else if(v[temp-a[i]]){
					v[temp]=true;
					ccount++;
					break;
				}
			}
			if(ccount>=Min)break;
			if(v[temp]==false){
				ccount=0;
				ans=temp;
			}
			temp++;
		}
		fprintf(fout,"%d\n",ans);
	}
	exit(0);
}


