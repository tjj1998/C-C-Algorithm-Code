/*
ID: huanshi
LANG: C
TASK: concom
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int G[110][110],ans[110][110];
int n,length;
void dfs(int i,int j)
{
	for (int k=1;k<=length;k++)
		if (i!=k && ans[i][k]<=50)
		{
			ans[i][k]+=G[j][k];
			if (ans[i][k]>50) dfs(i,k);
		}
}
int main()
{
	FILE *fin  = fopen ("concom.in", "r");
    FILE *fout = fopen ("concom.out", "w");
	fscanf(fin,"%d",&n);
	length=0;
	memset(G,0,sizeof(G));
	for (int i=1;i<=n;i++)
	{
		int a,b,c;
		fscanf(fin,"%d%d%d",&a,&b,&c);
		G[a][b]=c;
		if (a>length) length=a; 
		if (b>length) length=b;
	}
	memcpy(ans,G,sizeof(int)*110*110);
	for (int i=1;i<=length;i++)
		for (int j=1;j<=length;j++)
			if (ans[i][j]>50) dfs(i,j);
	for (int i=1;i<=length;i++)
		for (int j=1;j<=length;j++)
			if (i!=j && ans[i][j]>50)
				fprintf(fout,"%d %d\n",i,j);
	exit(0);
}

