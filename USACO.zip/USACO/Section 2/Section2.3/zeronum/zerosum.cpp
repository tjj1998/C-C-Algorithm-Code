/*
ID: huanshi
LANG: C
TASK: zerosum
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
FILE *fout;
int n,a[10];
void print(){
	fprintf(fout,"%d",1);
	int i;
	for(i=1;i<=n-1;i++){
		if(a[i]==0)	fprintf(fout," %d",i+1);
		if(a[i]==1)	fprintf(fout,"+%d",i+1);
		if(a[i]==2)	fprintf(fout,"-%d",i+1);		
	}
	fprintf(fout,"\n");
}
void test(){
	int i,sum=0,temp,flag=0;
	for(i=n;i>=1;i--){
		if(flag==0) 	temp=i;
		else 			temp=i*(int)pow(10,flag)+temp;		
		if(i==1)		{sum+=temp;break;}
				
		if(a[i-1]==0)	flag++;
		if(a[i-1]==1)	{sum+=temp;flag=0;}
		if(a[i-1]==2)	{sum-=temp;flag=0;}
	}
	if(sum==0)    	print();
}
void dfs(int step){
	if(step>=n) {
	test();
	return ;
	}
	int i;
	for(i=0;i<=2;i++){
		a[step]=i;
		dfs(step+1);
	}
}
int main() {
	FILE *fin  = fopen ("zerosum.in", "r");
    	  fout = fopen ("zerosum.out", "w");
    fscanf(fin,"%d",&n); 
	dfs(1);
	exit(0);
}


