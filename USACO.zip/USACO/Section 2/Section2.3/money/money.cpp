/*
ID: huanshi
LANG: C
TASK: money
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

long long int V,N,a[30],dp[10010];

int main(){
	FILE *fin  = fopen ("money.in", "r");
    FILE *fout = fopen ("money.out", "w");
	int i,j;
	fscanf(fin,"%lld%lld",&V,&N);
	for(i=0;i<V;i++){
		fscanf(fin,"%lld",&a[i]);
	}
	dp[0]=1;
	for(j=0;j<V;j++)
		for(i=a[j];i<=N;i++)
			dp[i]+=dp[i-a[j]];
	fprintf(fout,"%lld\n",dp[N]);
	return 0;
}
