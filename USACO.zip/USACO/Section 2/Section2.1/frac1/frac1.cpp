/*
ID: huanshi
LANG: C
TASK: frac1 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int n;
FILE *fout;
void fun(int a1,int b1,int a2,int b2){
	if(a1+a2>n||b1+b2>n) return ;
	else{
		fun(a1,b1,(a1+a2),(b1+b2));
		fprintf(fout,"%d/%d\n",a1+a2,b1+b2);
		fun((a1+a2),(b1+b2),a2,b2); 
	}	
}
int main() {
	FILE *fin  = fopen ("frac1.in", "r");
    fout = fopen ("frac1.out", "w");
    fscanf(fin,"%d",&n);
    fprintf(fout,"%d/%d\n",0,1);
    fun(0,1,1,1);    
    fprintf(fout,"%d/%d\n",1,1);
	exit(0);
}


