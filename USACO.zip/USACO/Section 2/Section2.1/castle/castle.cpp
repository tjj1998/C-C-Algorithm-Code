/*
ID: huanshi
LANG: C
TASK: castle
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int m,n,count=1;//count������¼�ڼ������ 
typedef struct A{
	int n;
	int w;
	int e;
	int s;
	
}A;
int ans[3000];
A ta[60][60];
int v[60][60];
void fun(int a,int b){//������������ 
	if(v[a][b]>0)return ;
	else{
	v[a][b]=count;
	ans[count]++; 
	if(ta[a][b].n==0)fun(a-1,b);
	if(ta[a][b].w==0)fun(a,b-1);
	if(ta[a][b].e==0)fun(a,b+1);
	if(ta[a][b].s==0)fun(a+1,b);
	}
}
int main() {
	FILE *fin  = fopen ("castle.in", "r");
    FILE *fout = fopen ("castle.out", "w");
    fscanf(fin,"%d%d",&m,&n);
    int i,j,temp;
	for(i=1;i<=n;i++){
		for(j=1;j<=m;j++){
			fscanf(fin,"%d",&temp);
			switch(temp){
				case 0:ta[i][j].n=0;ta[i][j].w=0;ta[i][j].e=0;ta[i][j].s=0;break;
				case 1:ta[i][j].n=0;ta[i][j].w=1;ta[i][j].e=0;ta[i][j].s=0;break;
				case 2:ta[i][j].n=1;ta[i][j].w=0;ta[i][j].e=0;ta[i][j].s=0;break;
				case 3:ta[i][j].n=1;ta[i][j].w=1;ta[i][j].e=0;ta[i][j].s=0;break;
				case 4:ta[i][j].n=0;ta[i][j].w=0;ta[i][j].e=1;ta[i][j].s=0;break;				
				case 5:ta[i][j].n=0;ta[i][j].w=1;ta[i][j].e=1;ta[i][j].s=0;break;
				case 6:ta[i][j].n=1;ta[i][j].w=0;ta[i][j].e=1;ta[i][j].s=0;break;
				case 7:ta[i][j].n=1;ta[i][j].w=1;ta[i][j].e=1;ta[i][j].s=0;break;
				case 8:ta[i][j].n=0;ta[i][j].w=0;ta[i][j].e=0;ta[i][j].s=1;break;
				case 9:ta[i][j].n=0;ta[i][j].w=1;ta[i][j].e=0;ta[i][j].s=1;break;
			   case 10:ta[i][j].n=1;ta[i][j].w=0;ta[i][j].e=0;ta[i][j].s=1;break;
			   case 11:ta[i][j].n=1;ta[i][j].w=1;ta[i][j].e=0;ta[i][j].s=1;break;
			   case 12:ta[i][j].n=0;ta[i][j].w=0;ta[i][j].e=1;ta[i][j].s=1;break;
			   case 13:ta[i][j].n=0;ta[i][j].w=1;ta[i][j].e=1;ta[i][j].s=1;break;
			   case 14:ta[i][j].n=1;ta[i][j].w=0;ta[i][j].e=1;ta[i][j].s=1;break;	
			   case 15:ta[i][j].n=1;ta[i][j].w=1;ta[i][j].e=1;ta[i][j].s=1;break;			   
			}			
		}
	}
	for(i=1;i<=n;i++){
		for(j=1;j<=m;j++){
			if(v[i][j]==0){
			fun(i,j);
			count++;
		}
		}
	}   
	int maxroom=0,max1=0,mx,my,tempmax;
	char mc;
	for(i=0;i<count;i++){
		maxroom=maxroom>ans[i]?maxroom:ans[i];
	}
//    for(i=1;i<=n;i++){
//    	for(j=1;j<m;j++)
//    	printf("%d ",v[i][j]);
//    	printf("%d\n",v[i][j]);
//	}
    for(j=m;j>=1; j--) 
	for(i=1;i<=n; i++){
	if(i+1<=n&&v[i][j]!=v[i+1][j]) {
	    tempmax = ans[v[i][j]] + ans[v[i+1][j]];
	    if(tempmax >= max1) {
		max1 = tempmax;
		mx = i+1;
		my = j;
		mc = 'N';
	    }
	}
	if(j-1>=1&&v[i][j]!=v[i][j-1]) {
	    tempmax = ans[v[i][j]] + ans[v[i][j-1]];
	    if(tempmax >= max1) {
		max1 = tempmax;
		mx = i;
		my = j-1;
		mc = 'E';
	    }
	}
    }
     fprintf(fout,"%d\n%d\n%d\n",count-1,maxroom,max1);
     fprintf(fout,"%d %d %c\n",mx,my,mc);
	exit(0);
}


