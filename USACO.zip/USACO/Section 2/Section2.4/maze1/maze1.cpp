/*
ID: huanshi
LANG: C++
TASK: maze1
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h> 
#include<algorithm>  
using namespace std;
#define INF 999999
int W,H,maze[210][100]; 
int way[110][50][4];
int ans[110][50];
int x[4]={-1,0,1,0},y[4]={0,1,0,-1};
int answer=0;
int max(int a,int b){
	return a>b?a:b;
}
void dfs(int a,int b,int step){
	int k;
	for(int k=0;k<4;k++){
		int x1=a+x[k],y1=b+y[k];
		if(way[a][b][k]){
			if(ans[x1][y1]>step){
				ans[x1][y1]=step;
				dfs(x1,y1,step+1);
			}
		}	
	}
}
int main(){
	FILE *fin  = fopen ("maze1.in", "r");
    FILE *fout = fopen ("maze1.out", "w");
    int i,j;
    fscanf(fin,"%d%d\n",&W,&H);
	char a;
	for(i=0;i<2*H+1;i++){
		for(j=0;j<2*W+2;j++){
			fscanf(fin,"%c",&a);
			if(a=='\n')break;
			else maze[i][j]=a;
		}
	}
	for(i=0;i<H;i++){
		for(j=0;j<W;j++){
			ans[i][j]=INF;
		}
	}
	for(i=0;i<H;i++){
		for(j=0;j<W;j++){
			for(int k=0;k<4;k++){
				int x1=2*i+1+x[k],y1=2*j+1+y[k];
				if(maze[x1][y1]==' '||maze[x1][y1]==0){
					if(x1==0||x1==2*H||y1==0||y1==2*W)ans[i][j]=1; 
					else	way[i][j][k]=1;
				}	
			}
		}	
	}
	for(i=0;i<H;i++){
		for(j=0;j<W;j++){
			if(ans[i][j]==1)dfs(i,j,2);
		}
	}
	for(i=0;i<H;i++){
		for(j=0;j<W;j++){
			answer=max(ans[i][j],answer);
		}
	}
//	for(i=0;i<H;i++){
//		for(j=0;j<W-1;j++)
//			printf("%d ",ans[i][j]);
//		printf("%d\n",ans[i][j]);
//	}
	fprintf(fout,"%d\n",answer); 
	exit(0);
}


