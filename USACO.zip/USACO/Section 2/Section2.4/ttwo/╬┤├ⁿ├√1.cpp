/*
ID: huanshi
LANG: C++
TASK: ttwo
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#define INF 2147483647
int maze[12][12];//��ͼ 
int fway[12][12][4],cway[12][12][4];//���ڼ�¼��һ�����ٴε���˵�ʱ�Ĳ��� 
int fcount=1,ccount=1;//��¼����
int fTras=0,cTras=0;//��¼���� 
int f[3],c[3];//0��1������λ�ã�2�����Ƿ��� 
int direction[4][2]={{-1,0},{0,1},{1,0},{0,-1}};//�ֱ�Ϊ���������ϣ��� 
int ans=INF,flag=0;
int min(int a,int b){
	return a<b?a:b;
}
void fbfs(){
	while(1){
		fcount++;
		if(maze[f[0]+direction[f[2]][0]][f[1]+direction[f[2]][1]]==0){//ʶ�������һ��ʱf��״̬ 
			f[2]=(f[2]+1)%4;
		}else{
			f[0]=f[0]+direction[f[2]][0];
			f[1]=f[1]+direction[f[2]][1];
		}
		if(fway[f[0]][f[1]][f[2]]){
			fTras=fcount-fway[f[0]][f[1]][f[2]];
			break;
		}else{
			fway[f[0]][f[1]][f[2]]=fcount;
		}
	}
}
void cbfs(){
	while(1){
		ccount++;
		if(maze[c[0]+direction[c[2]][0]][c[1]+direction[c[2]][1]]==0){//ʶ�������һ��ʱf��״̬ 
			c[2]=(c[2]+1)%4;
		}else{
			c[0]=c[0]+direction[c[2]][0];
			c[1]=c[1]+direction[c[2]][1];
		}
		if(cway[c[0]][c[1]][c[2]]){
			cTras=ccount-cway[c[0]][c[1]][c[2]];
			break;
		}else{
			cway[c[0]][c[1]][c[2]]=ccount;
		}
		for(int i=0;i<4;i++)
		if(fway[c[0]][c[1]][i]==ccount){
			ans=ccount;
			flag=1;
			break;
		}
	}
}
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int count(int a,int b,int a1,int b1){//ax+a1=by+b1=k������ax-by=b1-a1
	int temp,c;
	if(a1>b1){
		temp=a;a=b;b=temp;
		temp=a1;a1=b1;b1=temp;
	}
	c=b1-a1;
	if(gcd(fTras,cTras)>1){
		if(c%gcd(fTras,cTras)!=0)return INF;
	}
	int atemp=c/a,btemp=0;
	while(1){
	if(a*atemp-b*btemp==c)return a*atemp+a1;
	if(a*atemp-b*btemp<c){
		atemp++;
	}
	if(a*atemp-b*btemp>c){
		btemp++;
	}
	} 
}
void countmin(){
	for(int i=1;i<11;i++){
		for(int j=1;j<11;j++){
			for(int k=0;k<4;k++){
				for(int l=0;l<4;l++){
					if(fway[i][j][k]&&cway[i][j][l]){
						ans=min(ans,count(fTras,cTras,fway[i][j][k],cway[i][j][l]));
						//printf("%d %d %d %d %d\n",i,j,fway[i][j][k],cway[i][j][l],ans);
					}
				}
			}
		}
	}
}
int main(){
	FILE *fin  = fopen ("ttwo.in", "r");
    FILE *fout = fopen ("ttwo.out", "w");
	int i,j;
	for(i=1;i<=10;i++){
		for(j=1;j<=10;j++){
			char a;
			fscanf(fin,"%c",&a);
			if(a=='.'||a=='F'||a=='C') maze[i][j]=1;
			if(a=='F') f[0]=i,f[1]=j,fway[i][j][0]=1;
			if(a=='C') c[0]=i,c[1]=j,cway[i][j][0]=1;
		}
		fscanf(fin,"\n");
	}
	fbfs();
	cbfs();
	//printf("%d %d\n",fTras,cTras);
	if(ans!=INF)fprintf(fout,"%d\n",ans-1);
	else{
	countmin();
	if(ans==INF)fprintf(fout,"%d\n",0);
	else fprintf(fout,"%d\n",ans-1);
	}
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d ",maze[i][j]);
//			printf("%d\n",maze[i][j]);
//	}
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d\t",cway[i][j][0]);
//			printf("%d\n",cway[i][j][0]);
//	}
//	printf("\n");
//	printf("\n");
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d\t",fway[i][j][0]);
//			printf("%d\n",fway[i][j][0]);
//	}
//	printf("\n");
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d\t",fway[i][j][1]);
//			printf("%d\n",fway[i][j][1]);
//	}
//	printf("\n");
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d\t",fway[i][j][2]);
//			printf("%d\n",fway[i][j][2]);
//	}
//	printf("\n");
//	for(i=0;i<12;i++){
//		for(j=0;j<11;j++)
//			printf("%d\t",fway[i][j][3]);
//			printf("%d\n",fway[i][j][3]);
//	}
	exit(0);
}
