/*
ID: huanshi
LANG: C++
TASK: *
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int main(){
	for(int i=0;i<10;i++){
		int a;
		a+=2;
	}
	printf("%d %d\n",i,a);
	exit(0);
}


