/*
ID: huanshi
LANG: C++
TASK: comehome
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define V 100 
#define INF 99999999
int P,d[V],used[V],cost[V][V];
int min(int a,int b){
	return a<b?a:b;	
} 
void dijkstra(int s){
	fill(d,d+V,INF);
	fill(used,used+V,0);
	d[s]=0;
	while(1){
		int v=-1;
		for(int i=0;i<V;i++){
			if(!used[i]&&(v==-1||d[i]<d[v]))v=i;
		}
		if(v==-1)break;
		used[v]=1;
		for(int i=0;i<V;i++){
			d[i]=min(d[i],d[v]+cost[v][i]);
		}
	} 
}
int main(){
	FILE *fin  = fopen ("comehome.in", "r");
    FILE *fout = fopen ("comehome.out", "w");
	fscanf(fin,"%d\n",&P); 
	char a,b;
	int c;
	for(int i=0;i<V;i++){
		for(int j=0;j<V;j++){
			cost[i][j]=INF;
			if(i==j)cost[i][j]=0;
		}
	}
	for(int i=0;i<P;i++){
		fscanf(fin,"%c %c %d\n",&a,&b,&c);
		cost[a-'A'][b-'A']=min(cost[a-'A'][b-'A'],c);
		cost[b-'A'][a-'A']=min(cost[b-'A'][a-'A'],c);
	}
	dijkstra(25);
	int ans=INF;
	char letter=0;
	for(int i=0;i<25;i++){
		if(ans>d[i]){
			ans=d[i];
			letter=i;
		}
	}
	fprintf(fout,"%c %d\n",letter+'A',ans);
	exit(0);
}


