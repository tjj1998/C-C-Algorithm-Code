/*
ID: huanshi
LANG: C
TASK: barn1 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int m,s,c,a[210],ans[210],sum=0;
int cmp(const void *a,const void *b){
	return *(int *)a-*(int *)b;
}
int main(){
    FILE *fin  = fopen ("barn1.in", "r");
    FILE *fout = fopen ("barn1.out", "w");
    fscanf(fin,"%d%d%d",&m,&s,&c);
    int i;
    ans[0]=0;
	for(i=0;i<c;i++)
	fscanf(fin,"%d",&a[i]);		
	qsort(a,c,sizeof(a[0]),cmp);
	for(i=1;i<c;i++)
	ans[i]=a[i]-a[i-1];
    qsort(ans,c,sizeof(ans[0]),cmp); 
    if(m>=c)fprintf(fout,"%d\n",c);
	else{
	for(i=c-1;i>=c-m+1;i--){
    sum+=ans[i]-1;	
	}
	fprintf(fout,"%d\n",a[c-1]-a[0]+1-sum);
    }
	exit(0);
}


