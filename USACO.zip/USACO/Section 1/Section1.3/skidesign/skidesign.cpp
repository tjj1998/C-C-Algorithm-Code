/*
ID: huanshi
LANG: C
TASK: skidesign 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int n,minsum=99999999,a[1010];
int min(int a,int b){
	return a<b?a:b;
}
int fun(int pre,int temp,int pro){
	if(temp<pre)return pre-temp;
	if(temp>pro)return temp-pro;
	else return 0;
}
int main(){
    FILE *fin  = fopen ("skidesign.in", "r");
    FILE *fout = fopen ("skidesign.out", "w");
    fscanf(fin,"%d",&n);
    int i,j,max,sum;
    for(i=0;i<n;i++)
    fscanf(fin,"%d",&a[i]);
    for(i=0;i<=83;i++){
    	max=i+17;
    	sum=0;
    	for(j=0;j<n;j++){
    		sum+=fun(i,a[j],max)*fun(i,a[j],max);
		}
		minsum=min(minsum,sum);
	}
    fprintf(fout,"%d\n",minsum);
	exit(0);
}


