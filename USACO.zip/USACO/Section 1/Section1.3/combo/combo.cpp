/*
ID: huanshi
LANG: C
TASK: combo 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int p[3],q[3],n;
int fun(int a,int b){
	int i,j,count=0,temp1[5],temp2[5];
	for(i=0;i<5;i++){
		int t=a-2+i;
		if(t<=0)t=t+n;
		if(t>n)t=t-n; 
		temp1[i]=t;
	}
	for(i=0;i<5;i++){
		int t=b-2+i;
		if(t<=0)t=t+n;
		if(t>n)t=t-n;
		temp2[i]=t;
	}
	for(i=0;i<5;i++)
	for(j=0;j<5;j++)
	if(temp1[i]==temp2[j]){
		count++;
		break;
	}
	return count;
}
int main(){
    FILE *fin  = fopen ("combo.in", "r");
    FILE *fout = fopen ("combo.out", "w");
    fscanf(fin,"%d",&n);
    int i,sum=1;
    for(i=0;i<3;i++)
    fscanf(fin,"%d",&p[i]);
    for(i=0;i<3;i++)
    fscanf(fin,"%d",&q[i]);
    if(n<=5)fprintf(fout,"%d\n",n*n*n);
	else{
		for(i=0;i<3;i++){
			sum*=fun(p[i],q[i]);
		}
		sum=250-sum;
		fprintf(fout,"%d\n",sum);
	} 
	exit(0);
}


