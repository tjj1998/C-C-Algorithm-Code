/*
ID: huanshi
LANG: C
TASK: crypt1 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int n,a[10];
int fun(int p){
	while(p>0){
		if(!a[p%10])return 0;
		p=p/10;
	}
	return 1;
}
int main(){
    FILE *fin  = fopen ("crypt1.in", "r");
    FILE *fout = fopen ("crypt1.out", "w");
    fscanf(fin,"%d",&n);
    int i,temp,count=0;
    for(i=0;i<n;i++){
    	fscanf(fin,"%d",&temp);
    	a[temp]=1;
	}
    for(i=10000;i<99999;i++){
    	int p=i/100;
    	int q=i%100;
    	if(q<10) continue;
    	if(p*q>=10000)continue;
    	if(p*q/10>=1000)continue;
    	if(p*(q%10)>=1000)continue;
    	if(fun(p)&&fun(q)&&fun(p*(q/10))&&fun(p*(q%10))&&fun(p*q)){
		count++;
    }
	}
    fprintf(fout,"%d\n",count);
	exit(0);
}
