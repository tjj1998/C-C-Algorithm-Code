/*
ID: huanshi
LANG: C
TASK: milk
*/ 
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int m,n,count=0,sum=0;

typedef struct Milk{
	int a;
	int b;
}milk;
int cmp(const void *p,const void *q){
	milk *aa=(milk *)p;
    milk *bb=(milk *)q;
    return aa->a-bb->a;
}
milk farm[5010];
int main(){
    FILE *fin  = fopen ("milk.in", "r");
    FILE *fout = fopen ("milk.out", "w");
    fscanf(fin,"%d%d",&m,&n);
    if(m==0||n==0){
	fprintf(fout,"%d\n",0);
	exit(0);
    }
    int i;
	for(i=0;i<n;i++)
	fscanf(fin,"%d%d",&farm[i].a,&farm[i].b);
	qsort(farm,n,sizeof(farm[0]),cmp);
    for(i=0;i<n;i++){
    	if(count<m){
    		if(farm[i].b>=m-count){
    		fprintf(fout,"%d\n",sum+(m-count)*farm[i].a);
    		break;
    	    }
    		else{
    			count+=farm[i].b;
    			sum+=farm[i].b*farm[i].a;
			}
		}	
	}
	exit(0);
}

