/*
ID: huanshi
LANG: C
TASK: ariprog
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int a[150000],v[150000],m,n;
typedef struct Ans {	//��¼�������
	int x;
	int y;
} Ans;
Ans ans[150000];
int cmp(const void *p,const void *q){//������ 
	Ans *pp=(Ans *)p;
    Ans *qq=(Ans *)q;	
	return pp->y-qq->y;
	}
int acmp(const void *a,const void *b){
	return *(int *)a-*(int *)b;
} 
int main() {
	FILE *fin  = fopen ("ariprog.in", "r");
    FILE *fout = fopen ("ariprog.out", "w");
    fscanf(fin,"%d",&n);
    fscanf(fin,"%d",&m);
    int i,j,k,count=0,count1=0;
    for(i=0;i<=m;i++){
    	for(j=0;j<=m;j++){		
    		if(!v[i*i+j*j]){
    		a[count++]=i*i+j*j;
			v[i*i+j*j]=1;
		}
		}
	}
	qsort(a,count,sizeof(a[0]),acmp);
	for(i=0;i<count;i++){
		for(j=i+1;j<count;j++){
		if(a[i]+(a[j]-a[i])*(n-1)>m*m*2)break; 
		for(k=n-1;k>=2;k--){
			if(!v[a[i]+(a[j]-a[i])*k])break;
		}
		if(k==1){
			ans[count1].x=a[i];
			ans[count1++].y=a[j]-a[i];
		}
	}
	}
	qsort(ans,count1,sizeof(ans[0]),cmp);
	if(count1==0)fprintf(fout,"NONE\n");
	else
	for(i=0;i<count1;i++)
	fprintf(fout,"%d %d\n",ans[i].x,ans[i].y);
	exit(0);
}


