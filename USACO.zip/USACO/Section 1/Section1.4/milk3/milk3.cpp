/*
ID: huanshi
LANG: C
TASK: milk3 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int a,b,c,v[20][20][20],ans[20];
int min(int a,int b){
	return a<b?a:b;
}
void judge(int ta,int tb,int tc){
	if(v[ta][tb][tc])return ;
	else{
		v[ta][tb][tc]=1;
		if(ta==0&&ans[tc]==0)ans[tc]=1;
		if(ta!=0&&tb<b)
		judge(ta-min(ta,b-tb),tb+min(ta,b-tb),tc);
		if(ta!=0&&tc<c)
		judge(ta-min(ta,c-tc),tb,tc+min(ta,c-tc));
		if(tb!=0&&ta<a)
		judge(ta+min(tb,a-ta),tb-min(tb,a-ta),tc);
		if(tb!=0&&tc<c)
		judge(ta,tb-min(tb,c-tc),tc+min(tb,c-tc));
		if(tc!=0&&ta<a)
		judge(ta+min(tc,a-ta),tb,tc-min(tc,a-ta));
		if(tc!=0&&tb<b)
		judge(ta,tb+min(tc,b-tb),tc-min(tc,b-tb));
	}
}
int main() {
	FILE *fin  = fopen ("milk3.in", "r");
    FILE *fout = fopen ("milk3.out", "w");
    fscanf(fin,"%d %d %d",&a,&b,&c);
	int i,j;
    judge(0,0,c);
    for(i=0;i<c;i++)
    if(ans[i])
	fprintf(fout,"%d ",i);
	fprintf(fout,"%d\n",c);
	exit(0);
}


