/*
ID: huanshi
LANG: C
TASK: sprime 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
FILE *fout;
int n;
int fun(int a){
	int i;
	for(i=2;i<=sqrt(a);i++){
		if(a%i==0)return 0;
	}
	return 1;
}
void dfs(int step,int a){
	int i;
	if(step==n){
		if(fun(a))fprintf(fout,"%d\n",a);
		return ;
	}
	for(i=1;i<=9;i++){
		if(step==0&&i==1)continue; 
		if(fun(a*10+i))dfs(step+1,a*10+i);
	}
}
int main(){
    FILE *fin  = fopen ("sprime.in", "r");
          fout = fopen ("sprime.out", "w");
    fscanf(fin,"%d",&n);
	dfs(0,0);
	exit(0);
}


