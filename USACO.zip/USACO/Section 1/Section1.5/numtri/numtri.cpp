/*
ID: huanshi
LANG: C
TASK: numtri 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int dp[1010],n; 
int max(int a,int b){
	return a>b?a:b;
}
int main(){
    FILE *fin  = fopen ("numtri.in", "r");
    FILE *fout = fopen ("numtri.out", "w");
    fscanf(fin,"%d",&n);
    int i,j,temp,max1=0;
	for(i=1;i<=n;i++){
		for(j=i;j>=1;j--){
		fscanf(fin,"%d",&temp);
		dp[j]=max(dp[j-1]+temp,dp[j]+temp);
	} 
    }
    for(i=1;i<=n;i++)
    max1=max(max1,dp[i]);
    fprintf(fout,"%d\n",max1);
	exit(0);
}


