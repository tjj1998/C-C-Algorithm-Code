/*
ID: huanshi
LANG: C
TASK: pprime 
*/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int ans[100010],count=0;
int fun(int a){
	int i;
	for(i=2;i<=sqrt(a);i++){
		if(a%i==0)return 0;
	}
	return 1;
}
int main(){
    FILE *fin  = fopen ("pprime.in", "r");
    FILE *fout = fopen ("pprime.out", "w");
    int a,b;
    fscanf(fin,"%d%d",&a,&b);
    int i,a1,a2,a3,a4,flag=0,flag1=0;
	for(a1=0;a1<=9;a1++){
		if(flag==1)break;
		for(a2=0;a2<=9;a2++){
			if(flag==1)break;
			for(a3=0;a3<=9;a3++){
				if(flag==1)break;
				for(a4=0;a4<=9;a4++){
					int temp;
					if(a1){temp=a1*1000000+a2*100000+a3*10000+a4*1000+a3*100+a2*10+a1;}
					else if(a2){temp=a2*10000+a3*1000+a4*100+a3*10+a2;}
					else if(a3){
					if(b>=11&&flag1==0){
					if(a<=11)
					ans[count++]=11;
					flag1=1;
					}
					temp=a3*100+a4*10+a3;}
					else temp=a4; 
					if(temp>b){
					flag=1;
					break;
				    }
					else if(fun(temp)&&temp>=a)
						   ans[count++]=temp;
				}
			}
		}
	}
    for(i=0;i<count;i++){
    	fprintf(fout,"%d\n",ans[i]);
	}
	exit(0);
}


