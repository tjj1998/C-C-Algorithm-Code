/*
ID: huanshi
LANG: C
TASK: namenum
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
char n[15];
int count,count1=0;
char a[20],name[5000][20];
FILE *fout; 
void judge(){
    int pre=0,pro=count-1,temp;
	while(pro-pre>1){
        temp=(pro+pre)/2;
		if(strcmp(a,name[temp])==0){
		fprintf(fout,"%s\n",a);
		count1++;
		break;
		}
		if(strcmp(a,name[temp])>0){
			pre=temp;
		}
		else pro=temp;
	}
	if(pro-pre<=1){
	if(strcmp(a,name[pro])==0){
    fprintf(fout,"%s\n",a);
    count1++;
	}
}
}
void fun(int step){
	if(step==strlen(n)){
		judge();
	}
	else{
		switch(n[step]-'0'){
			case 2:a[step]='A';fun(step+1);a[step]='B';fun(step+1);a[step]='C';fun(step+1);break;
			case 3:a[step]='D';fun(step+1);a[step]='E';fun(step+1);a[step]='F';fun(step+1);break;
			case 4:a[step]='G';fun(step+1);a[step]='H';fun(step+1);a[step]='I';fun(step+1);break;
			case 5:a[step]='J';fun(step+1);a[step]='K';fun(step+1);a[step]='L';fun(step+1);break;
			case 6:a[step]='M';fun(step+1);a[step]='N';fun(step+1);a[step]='O';fun(step+1);break;
			case 7:a[step]='P';fun(step+1);a[step]='R';fun(step+1);a[step]='S';fun(step+1);break;
			case 8:a[step]='T';fun(step+1);a[step]='U';fun(step+1);a[step]='V';fun(step+1);break;
			case 9:a[step]='W';fun(step+1);a[step]='X';fun(step+1);a[step]='Y';fun(step+1);break; 
		}
	    }
	}
int main(){
	FILE *fin = fopen("namenum.in","r");
    FILE *fin2 = fopen("dict.txt","r");
    fout=fopen("namenum.out","w");
	int i=0; 
	while(fscanf(fin2,"%s",name[i])!=EOF){
		i++;
	} 
	count=i;
	fscanf(fin,"%s",n);
	fun(0); 
	if(count1==0) fprintf(fout,"NONE\n");
    exit(0);
}

