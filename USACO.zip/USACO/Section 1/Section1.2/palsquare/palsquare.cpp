/*
ID: huanshi
LANG: C
TASK: palsquare
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
FILE *fout;
char a[50],c[50];
int b;
char change(int t){
	switch(t){
		case 0:return '0';
		case 1:return '1';
		case 2:return '2';
		case 3:return '3';
		case 4:return '4';
		case 5:return '5';
		case 6:return '6';
		case 7:return '7';
		case 8:return '8';
		case 9:return '9';
		case 10:return 'A';
		case 11:return 'B';
		case 12:return 'C';
		case 13:return 'D';
		case 14:return 'E';
		case 15:return 'F';
		case 16:return 'G';
		case 17:return 'H';
		case 18:return 'I';
		case 19:return 'J';
	}
}
void judge(int n){
	int i,j,count1=0,count2=0;
	int t=n*n;
	while(n){//��ԭ����ת����B���� 
	a[count1++]=change(n%b);
	n=n/b;	
	}
	while(t){//��ƽ��ת����B���� 
	c[count2++]=change(t%b);
	t=t/b;	
	}
	for(i=0;i<count2/2;i++){//�ж��Ƿ�Ϊ������ 
		if(c[i]!=c[count2-i-1])break;
	}
	
	if(i==count2/2){
	for(j=count1-1;j>=0;j--)
	fprintf(fout,"%c",a[j]);
	fprintf(fout," ");
	for(j=count2-1;j>=0;j--)
	fprintf(fout,"%c",c[j]);
	fprintf(fout,"\n");
    } 
}
int main(){
	FILE *fin=fopen("palsquare.in","r");
	fout=fopen("palsquare.out","w"); 
	int i,j;
	fscanf(fin,"%d",&b);
	for(i=1;i<=300;i++){
		judge(i); 
	}
    exit(0);
}

