
/*
ID: huanshi
LANG: C
TASK: dualpal 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int count,a[40],n,s,sum=0;
int judge(int n,int b){
	int i,j,count1=0;
	while(n){//��ԭ����ת����B���� 
	a[count1++]=n%b;
	n=n/b;	
	}
	for(i=0;i<count1/2;i++){//�ж��Ƿ�Ϊ������ 
		if(a[i]!=a[count1-i-1])break;
	}
	if(i==count1/2)return 1;
	else return 0;
    }
int main () {
    FILE *fin  = fopen ("dualpal.in", "r");
    FILE *fout = fopen ("dualpal.out", "w");
    fscanf(fin,"%d %d",&n,&s);
    int i,j;
    for(i=s+1;sum<n;i++){
    	count=0;
          for(j=2;j<=10&&count<2;j++){
          	if(judge(i,j)){
			  count++;
		  }
	      }
	      if(count==2){
		    fprintf(fout,"%d\n",i);
		    sum++;
		    }
	}
	exit(0);
}
