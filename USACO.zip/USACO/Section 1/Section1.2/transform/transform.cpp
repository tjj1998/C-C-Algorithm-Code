/*
ID: huanshi
LANG: C
TASK: transform
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
char a[15][15],b[15][15],test[15][15],temp[15][15];
int n;
void transform(char a[][15]){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			temp[j][n-1-i]=a[i][j];
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j]=temp[i][j];
		}
	}	
}
void transform2(char a[][15]){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			temp[i][n-1-j]=a[i][j];
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			b[i][j]=temp[i][j];
		}
	}	
}
int  judge(char b[][15]){
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(test[i][j]!=b[i][j])
			return 0;
		}
	}
	return 1;
}
int main(){
	FILE *fin  = fopen ("transform.in", "r");
    FILE *fout = fopen ("transform.out", "w");
	int i,j;
	fscanf(fin,"%d\n",&n);
	for(i=0;i<n;i++){
		for(j=0;j<n-1;j++)
		fscanf(fin,"%c",&a[i][j]);
		fscanf(fin,"%c\n",&a[i][j]);
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
		fscanf(fin,"%c",&test[i][j]);
		fscanf(fin,"%c\n",&test[i][j]);
	}
	transform(a);
	if(judge(b))
	fprintf(fout,"1\n");
	else{
		transform(b);
		if(judge(b))
		fprintf(fout,"2\n");
		else{
			transform(b);
			if(judge(b))
		    fprintf(fout,"3\n");
		    else{
		    	transform2(a);
		        if(judge(b))
		        fprintf(fout,"4\n");
		        else{
		        	int count=0;
		        	while(count<3){
		        		transform(b);
		        		if(judge(b)){	
		        			fprintf(fout,"5\n");
		        			break;
						}
					    count++;	
					}
					if(count>=3){
						if(judge(a))
						fprintf(fout,"6\n");
						else
						fprintf(fout,"7\n");
					}
				}
			}
		}
	}
    exit(0);
}

