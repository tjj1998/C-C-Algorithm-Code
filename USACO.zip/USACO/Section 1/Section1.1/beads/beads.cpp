
/*
ID: huanshi
LANG: C
TASK: beads 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char necklace[400];
char nl[800];
int a,b,n;
int max(int a,int b){
	return a>b?a:b;
}
int main () {
    FILE *fin  = fopen ("beads.in", "r");
    FILE *fout = fopen ("beads.out", "w");
    fscanf(fin,"%d",&n);
    fscanf(fin,"%s",necklace);
    strcpy(nl,necklace);
    strcat(nl,necklace);
    int i,flag=0;
    int max1=0;
    char temp;
    int countw=0;
    int count=0; 
    for(i=0;i<2*n;i++){
		if(nl[i]=='r'&&flag==0){
    	a=1;
		b=0;
		flag=1;
		temp='r';
		continue;	
		}
		if(flag){//�ж�֮ǰ�ж��ٸ�w 
			if(nl[i]=='w'){
			if(nl[i-1]=='w')
			countw++;	
			else 
			countw=1;
			}
		if(temp!=nl[i]&&nl[i]!='w'){//��a��ֵ��b���� 
		temp=nl[i]; 
		max1=max(max1,a+b-count);
    	b=a;		
    	a=1;
    	    if(nl[i-1]=='w'){
    	     a+=countw;
    	     count=countw;
            } 
			else count=0;
	    }
	    else a++;
	}
    } 
    if(max1>n)max1=n; 
    if(max1==0)max1=n;
	fprintf(fout,"%d\n",max1);
	exit(0);
}
