
/*
ID: huanshi
LANG: C
TASK: friday 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int y,m,d,w;
int s[7];
int main () {
    FILE *fin  = fopen ("friday.in", "r");
    FILE *fout = fopen ("friday.out", "w");
    int i,n;
    fscanf (fin, "%d", &n);
    int year =1900;
    for(i=1;year<1900+n;i++){
	if(i>12){
		i=1;
		year++;
		if(year>=1900+n)
		break;
	}
	if(i<3){
   	m=i+12;
   	y=year-1;
    }
    else{
    m=i;
    y=year;
    }
   	d=13;
    w=(y+y/4+y/400-y/100+m*2+3*(m+1)/5+d)%7;
    s[w]++;
    }
    	fprintf(fout,"%d %d %d %d %d %d %d\n",s[5],s[6],s[0],s[1],s[2],s[3],s[4]);
    exit(0);
}
