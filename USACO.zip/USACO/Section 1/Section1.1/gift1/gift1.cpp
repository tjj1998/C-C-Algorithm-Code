/*
ID: huanshi
LANG: C
TASK: gift1 
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char a[15][20]; 
int b[15];
int main () {
    FILE *fin  = fopen ("gift1.in", "r");
    FILE *fout = fopen ("gift1.out", "w");
    int mon, peo, n, i, j, k;
    fscanf (fin, "%d", &n);
    for(i=0;i<n;i++){
    	fscanf(fin,"%s",a[i]);
	}
	char p[20],temp[20]; 
	for(k=0;k<n;k++){
		fscanf(fin,"%s",p);
		fscanf(fin,"%d %d",&mon,&peo);
		for(i=0;i<peo;i++){
		fscanf(fin,"%s",temp);
		for(j=0;j<n;j++){
			if(strcmp(temp,a[j])==0){
			b[j]+=mon/peo;
			break;
		    }
		}
	    }
	    if(peo!=0)
	    for(i=0;i<n;i++){
			if(strcmp(p,a[i])==0){
				b[i]-=mon;
			b[i]+=mon%peo;
			break;
		    }
		}
	}
    for(i=0;i<n;i++){
    	fprintf(fout,"%s %d\n",a[i],b[i]);
	}
    exit(0); 
}
