/*
ID: huanshi
LANG: C++
TASK: ratios
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
int a[3],b[3],c[3],d[3];
int fun(int a[],int b[],int c[]){//��������ʽ���㹫ʽ 
	return a[0]*(b[1]*c[2]-c[1]*b[2])-a[1]*(b[0]*c[2]-c[0]*b[2])+a[2]*(b[0]*c[1]-c[0]*b[1]);
}
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}

int main(){
	FILE *fin  = fopen ("ratios.in", "r");
    FILE *fout = fopen ("ratios.out", "w");
	fscanf(fin,"%d%d%d",&d[0],&d[1],&d[2]);
	fscanf(fin,"%d%d%d",&a[0],&a[1],&a[2]);
	fscanf(fin,"%d%d%d",&b[0],&b[1],&b[2]);
	fscanf(fin,"%d%d%d",&c[0],&c[1],&c[2]);
	int d0=fun(a,b,c);//ϵ������ 
	int d1=fun(d,b,c);//���1����, x1=d1/d0 
	int d2=fun(a,d,c);//���2����, x2=d2/d0
	int d3=fun(a,b,d);//���3����x3=d3/d0 
//	printf("%d %d %d %d\n",d0,d1,d2,d3);
	if(d0<0){
		d0=-d0;d1=-d1;d2=-d2;d3=-d3;
//		printf("%d %d %d %d\n",d0,d1,d2,d3);
	}
	if(d0==0||d1<0||d2<0||d3<0)
	fprintf(fout,"NONE\n");
	else{
		int temp=gcd(d0,gcd(d1,gcd(d2,d3)));
//		printf("%d %d %d %d\n",d0,d1,d2,d3);
		fprintf(fout,"%d %d %d %d\n",d1/temp,d2/temp,d3/temp,d0/temp);
	}
	exit(0);
}


