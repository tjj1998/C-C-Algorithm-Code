/*
ID: huanshi
LANG: C++
TASK: butter
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<vector>
#include<queue>
#include<algorithm>
#define INF 99999999
using namespace std;
struct edge { int to,cost; };
typedef pair<int,int>P;

int N,V,C;
vector<edge> G[810];
int d[810],ans[510];
int answer=INF;

int dijkstra(int s){
	int temp=0;
	priority_queue<P,vector<P>, greater<P> >que;
	fill(d,d+V+1,INF);
	d[s]=0;
	que.push(P(0,s));
	
	while(!que.empty()){
		P p=que.top();que.pop();
		int v=p.second;
		if(d[v]<p.first)continue;
		for(int i=0;i<G[v].size();i++){
			edge e=G[v][i];
			if(d[e.to]>d[v]+e.cost){
				d[e.to]=d[v]+e.cost;
				que.push(P(d[e.to],e.to));
			}
		}
	}
	for(int i=0;i<N;i++){
		if(d[ans[i]]!=EOF)
		temp+=d[ans[i]];
		else {
			temp=INF;break;
		}
	}
	return temp;
}
int main(){
	FILE *fin  = fopen ("butter.in", "r");
    FILE *fout = fopen ("butter.out", "w");
	fscanf(fin,"%d%d%d",&N,&V,&C);
	for(int i=0;i<N;i++)
	fscanf(fin,"%d",&ans[i]);
	int a,b,c;
	for(int i=0;i<C;i++){
		fscanf(fin,"%d%d%d",&a,&b,&c);
		edge p;
		p.to=b,p.cost=c;
		G[a].push_back(p);
		p.to=a,p.cost=c;
		G[b].push_back(p);
	}
	for(int i=1;i<=V;i++){
		answer=min(answer,dijkstra(i));
	}
	fprintf(fout,"%d\n",answer);
	exit(0);
}


