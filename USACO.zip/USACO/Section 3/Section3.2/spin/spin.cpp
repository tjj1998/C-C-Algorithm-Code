/*
ID: huanshi
LANG: C++
TASK: spin
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
 
FILE *fin = fopen("spin.in", "r");
FILE *fout = fopen("spin.out", "w");
 
bool f[6][360];
int s[6],g[6];
 
bool fun(int a)
{
  	for (int i = 1; i <= 5; i++)
		if (!f[i][(g[i] + a) % 360]) return false;
  	return true;
}
 
int main(){
	int ccount,a,b;
  	for(int i=1;i<=5;i++){
      	fscanf(fin,"%d%d",&s[i],&ccount);
      	s[i]=360-s[i];//���䲻������ô�����ٶȱ�Ϊ360-v 
      	for(int j=1;j<=ccount;j++){
          	fscanf(fin,"%d%d",&a,&b);
          	for(int k=0;k<=b;k++)
            f[i][(a+k)%360]=true;
        }
    }
	int flag=-1;
  	for(int i=0;i<360;i++){
    	if(flag!=-1) break;
      	else{
          	for(int j=0;j<360;j++)//�ж��Ƿ��غ� 
            	if (fun(j)) {flag=i; break;}
          	for (int j=1;j<=5;j++)//ǰ����·�� 
            	g[j]+=s[j];
        }
	}
  	if(flag!=-1) fprintf(fout,"%d\n",flag);
    else fprintf(fout,"none\n");
  	exit(0);
}


