/*
ID: huanshi
LANG: C++
TASK: msquare
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
FILE *fin,*fout;
bool hash[40321];
int s[150000][9],flag=0;//ans[i][0]��¼ǰһ�ε�λ�úͱ任��ʽ�� 
int factorial[8]={0,1,2,6,24,120,720,5040};
int Anscantor=0;
int ans[100],ccount=0;
int Cantor(int a[]){//����չ�� 
	int sum=0;
	bool v[9];
	memset(v,0,sizeof(v));
	for(int i=8;i>1;i--){
		int temp=0;
		for(int j=1;j<a[i];j++){
			if(!v[j])temp++;
		}
		sum+=temp*factorial[i-1];
		v[a[i]]=true;
	}
	return sum;
}
void test(int road){//��ȡ·�� 
	while(s[road][0]){
		ans[ccount++]=s[road][0]%10;
		road=s[road][0]/10;
	}
}
void A(int a[]){
	int temp;
	for(int i=1;i<=4;i++){
		temp=a[i];
		a[i]=a[4+i];
		a[4+i]=temp;
	}
} 
void B(int a[]){
	int temp;
	temp=a[1];a[1]=a[4];a[4]=a[3];a[3]=a[2];a[2]=temp;
	temp=a[5];a[5]=a[8];a[8]=a[7];a[7]=a[6];a[6]=temp;
} 
void BT(int a[]){
	int temp;
	temp=a[1];a[1]=a[2];a[2]=a[3];a[3]=a[4];a[4]=temp;
	temp=a[5];a[5]=a[6];a[6]=a[7];a[7]=a[8];a[8]=temp;
} 
void CT(int a[]){
	int temp;
	temp=a[2];a[2]=a[3];a[3]=a[7];a[7]=a[6];a[6]=temp;
}
void C(int a[]){
	int temp;
	temp=a[2];a[2]=a[6];a[6]=a[7];a[7]=a[3];a[3]=temp;
}
void copy(int pre,int t,int a[],int b[]){ 
	for(int i=1;i<=8;i++)
	b[i]=a[i];
	b[0]=pre*10+t;
}
int bfs(){
	int l=0,r=1;
	while(l<r){	
		int temp=Cantor(s[l]);
		if(temp==Anscantor){
			test(l);break;
		}
		if(!hash[temp]){
			A(s[l]);copy(l,1,s[l],s[r++]);A(s[l]);
			B(s[l]);copy(l,2,s[l],s[r++]);BT(s[l]);
			C(s[l]);copy(l,3,s[l],s[r++]);CT(s[l]);
			hash[temp]=true;
		}
		l++;		
	}
}
void printAns(){
	fprintf(fout,"%d\n",ccount);
	for(int i=ccount-1;i>=0;i--){
		if(ans[i]==1)fprintf(fout,"A");
		if(ans[i]==2)fprintf(fout,"B");
		if(ans[i]==3)fprintf(fout,"C");
	}
	fprintf(fout,"\n");
}
int main(){
	fin  = fopen ("msquare.in", "r");
    fout = fopen ("msquare.out", "w");
    int temp[9];
    for(int i=1;i<=4;i++){
		fscanf(fin,"%d",&temp[i]);
		s[0][i]=i;
	}	
	for(int i=8;i>=5;i--){
		fscanf(fin,"%d",&temp[i]);
		s[0][i]=13-i;
	}	
	Anscantor=Cantor(temp);
	bfs();
	printAns();
	exit(0);
}


