/*
ID: huanshi
LANG: C++
TASK: camelot
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#include<queue>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int M,N;
int king[2];
int ans=INF;
int knight[780][2],Tcount=0;
int Range[31][27][31][27];
typedef pair<int,int>P;
queue<P> q;
int a[8][2]={{2,1},{2,-1},{-2,1},{-2,-1},{1,2},{1,-2},{-1,2},{-1,-2}};

int bfs(int m,int n){
	Range[m][n][m][n]=0;
	q.push(P(m,n));
	while(q.size()){
		P p=q.front();q.pop();
		int x=p.first,y=p.second;
		for(int i=0;i<8;i++)
		if(x+a[i][0]>=1&&x+a[i][0]<=M&&y+a[i][1]>=1&&y+a[i][1]<=N){
			if(Range[m][n][x+a[i][0]][y+a[i][1]]>Range[m][n][x][y]+1){
				Range[m][n][x+a[i][0]][y+a[i][1]]=Range[m][n][x][y]+1;
				q.push(P(x+a[i][0],y+a[i][1]));
			}
		}
	}
}
int judge(int m,int n){//�ж��Ѵ˵�Ϊ���ϵ�����ٲ��� 
	int king_own=max(abs(king[0]-m),abs(king[1]-n));
	int sum=king_own;
	for(int i=0;i<Tcount;i++){
		sum+=Range[knight[i][0]][knight[i][1]][m][n];
	}
	int temp=sum;
	for(int i=0;i<Tcount;i++)
		for(int j=-2;j<=2;j++)
			for(int k=-2;k<=2;k++){
				if(king[0]+j>=1&&king[0]+j<=M&&king[1]+k>=1&&king[1]+k<=N){
					int king_union=max(abs(j),abs(k))+Range[knight[i][0]][knight[i][1]][king[0]+j][king[1]+k]
							  	  +Range[king[0]+j][king[1]+k][m][n];
					temp=min(temp,sum-king_own-Range[knight[i][0]][knight[i][1]][m][n]+king_union);
				}
			}
	return temp;
}
int main(){
	fin  = fopen ("camelot.in", "r");
    fout = fopen ("camelot.out", "w");
    fscanf(fin,"%d%d\n",&M,&N);
    fscanf(fin,"%c%d",&king[1],&king[0]);
    king[1]-='A'-1;
    for(int i=1;i<=M;i++)
    	for(int j=1;j<=N;j++)
    		for(int k=1;k<=M;k++)
    			for(int l=1;l<=N;l++)
    				Range[i][j][k][l]=INF;
    while(fscanf(fin,"\n%c%d",&knight[Tcount][1],&knight[Tcount][0])!=EOF){
		knight[Tcount][1]-='A'-1;
		Tcount++;
    }
    for(int i=1;i<=M;i++){
		for(int j=1;j<=N;j++){
			bfs(i,j);
		}
	}
	for(int i=1;i<=M;i++){
		for(int j=1;j<=N;j++){
			ans=min(ans,judge(i,j));
		}
	}
	fprintf(fout,"%d\n",ans);
	exit(0);
}


