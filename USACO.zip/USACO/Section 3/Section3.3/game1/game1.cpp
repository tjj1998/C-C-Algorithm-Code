/*
ID: huanshi
LANG: C++
TASK: game1
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int N,sum[210],dp[210][210];
int ans=0;

int main(){
	fin  = fopen ("game1.in", "r");
    fout = fopen ("game1.out", "w");
	fscanf(fin,"%d",&N);
	int a;
	for(int i=1;i<=N;i++){
		fscanf(fin,"%d",&a);
		sum[i]=sum[i-1]+a;
		dp[i][i]=a;
	}
	for(int i=N-1;i>=1;i--){
		for(int j=i+1;j<=N;j++){
			dp[i][j]=sum[j]-sum[i-1]-min(dp[i][j-1],dp[i+1][j]);
		}
	}
	fprintf(fout,"%d %d\n",dp[1][N],sum[N]-dp[1][N]);
	exit(0);
}


