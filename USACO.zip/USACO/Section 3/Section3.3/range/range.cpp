/*
ID: huanshi
LANG: C++
TASK: range
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int N;
int dp[260][260]; 
int ans[260];
int main(){
	fin  = fopen ("range.in", "r");
    fout = fopen ("range.out", "w");
	fscanf(fin,"%d\n",&N);
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			fscanf(fin,"%c",&dp[i][j]);
			dp[i][j]-='0';
			if(i>=1&&j>=1&&dp[i][j])
			dp[i][j]=min(dp[i-1][j],min(dp[i][j-1],dp[i-1][j-1]))+1;
			for(int k=2;k<=dp[i][j];k++)
			ans[k]++;
		}
		fscanf(fin,"\n");
	}	
	for(int i=2;ans[i]>0;i++)
	fprintf(fout,"%d %d\n",i,ans[i]);	
	exit(0);
}


