/*
ID: huanshi
LANG: C++
TASK: fence
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#include<vector>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int F;
int pre=INF,pro=0;
int G[510][510];
int route[1030],rcount=0;
int ans[1030],acount=0;
int d[510];
void printRoute(){
	for(int i=0;i<rcount-1;i++){
		printf("%d ",route[i]);
	}
	printf("%d\n",route[rcount-1]);
}
void printAns(){
	for(int i=0;i<acount-1;i++){
		printf("%d ",ans[i]);
	}
	printf("%d\n",ans[acount-1]);
}
void find_circuit(int a){
	int flag=0;
	for(int i=pre;i<=pro;i++){
		if(G[a][i]){
			flag=1;
			route[rcount++]=a;
			printRoute();
			G[a][i]--;
			G[i][a]--;
			find_circuit(i);
		}
	}
	if(!flag){
		ans[acount++]=a;
		printAns();
		rcount--;
		if(rcount>=0)
		find_circuit(route[rcount]);
	}
}
void print(){
	for(int i=acount-1;i>=0;i--){
		fprintf(fout,"%d\n",ans[i]);
	}
}
int main(){
	fin  = fopen ("fence.in", "r");
    fout = fopen ("fence.out", "w");
    int a,b;
    fscanf(fin,"%d",&F);
	for(int i=0;i<F;i++){
		fscanf(fin,"%d%d",&a,&b);
		G[a][b]++; 
		G[b][a]++;
		d[a]++;
		d[b]++;
		pre=min(pre,min(a,b));
		pro=max(pro,max(a,b));	
	}
	int flag=0;
	for(int i=pre;i<=pro;i++){
		if(d[i]%2==1){
			flag=i;break;
		}
	}
	if(flag==0) 
	find_circuit(pre);
	else
	find_circuit(flag);
	print();
	exit(0);
}


