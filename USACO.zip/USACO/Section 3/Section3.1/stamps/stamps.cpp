/*
ID: huanshi
LANG: C++
TASK: stamps
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
int K,N;
int dp[2000010],a[60];
int main(){
	FILE *fin  = fopen ("stamps.in", "r");
    FILE *fout = fopen ("stamps.out", "w");
	fscanf(fin,"%d%d",&K,&N);
	for(int i=0;i<N;i++){
		fscanf(fin,"%d",&a[i]);
	}
	sort(a,a+N); 
	for(int i=0;i<2000010;i++){
		dp[i]=INF;
	}
	dp[0]=0;
	int ccount=1;
	while(1){
		for(int i=0;i<N;i++){
			if(ccount-a[i]>=0)
			dp[ccount]=min(dp[ccount],dp[ccount-a[i]]+1);
		}
		if(dp[ccount]>K){
			fprintf(fout,"%d\n",ccount-1);
			break;
		}
		ccount++;
	}
	exit(0);
}


