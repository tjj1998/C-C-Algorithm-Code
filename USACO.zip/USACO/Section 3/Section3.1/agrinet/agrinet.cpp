/*
ID: huanshi
LANG: C++
TASK: agrinet
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
#define INF 99999999

int N;
int cost[110][110];
int mincost[110];
int used[110];
int prim(){
	for(int i=0;i<N;i++){
		mincost[i]=INF;
		used[i]=0;
	}
	mincost[0]=0;
	int res=0;
	
	while(1){
		int v=-1;
		for(int i=0;i<N;i++){
			if(!used[i]&&(v==-1||mincost[i]<mincost[v]))v=i;
		}
		if(v==-1)break;
		used[v]=1;
		res+=mincost[v];
		for(int i=0;i<N;i++){
			if(mincost[i]>cost[v][i]&&i!=v)mincost[i]=cost[v][i];
		}
	}
	return res;		
}
int main(){
	FILE *fin  = fopen ("agrinet.in", "r");
    FILE *fout = fopen ("agrinet.out", "w");
	fscanf(fin,"%d",&N);
	int a;
	for(int i=0;i<N;i++){
		for(int j=0;j<N;j++){
			fscanf(fin,"%d",&cost[i][j]);
		}
	}
	fprintf(fout,"%d\n",prim()); 
	exit(0);
}


