/*
ID: huanshi
LANG: C++
TASK: contact
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
using namespace std;
int A,B,N;
int ccount=0;
char a[200010];
FILE *fout; 
typedef struct T{
	int x;
	int y;
}T;
T ans[10000];
bool cmp(T p,T q){
	if(p.y>q.y)return true;
	else if(p.y==q.y&&p.x<q.x)return true;
	else return false;
}
int fun(int t){
	int tcount=0,temp[13];
	while(t){
		temp[tcount++]=t&1;
		t>>=1;
	}
	for(int i=tcount-2;i>=0;i--){
	fprintf(fout,"%d",temp[i]);
	}
}

int main(){
	FILE *fin  = fopen ("contact.in", "r");
    fout = fopen ("contact.out", "w");
	fscanf(fin,"%d%d%d\n",&A,&B,&N);
	for(int i=0;i<10000;i++){
		ans[i].x=i;
		ans[i].y=0;
	}
	while(fscanf(fin,"%c",&a[ccount])!=EOF){
		if(a[ccount]=='\n')continue;
		ccount++;
	}
	for(int i=0;i<ccount;i++){
		long int t=1;
		for(int j=0;j<B;j++){
			if(i+j>=ccount)break;
			else {
				t<<=1;
				t+=(a[i+j]-'0');
				if(j>=A-1){
					if(t<0)break;
					ans[t].y++;	
				}
			}
		}
	}
	sort(ans,ans+10000,cmp);
	int flag=0,anscount;
	for(int i=0;flag<=N;i++){
		if(ans[i].y>=1){
			if(i==0){
				fprintf(fout,"%d\n",ans[i].y);
				fun(ans[i].x);
				anscount=1;
				flag++;
			}
			else if(ans[i-1].y!=ans[i].y){
				if(flag==N)break;
				fprintf(fout,"\n%d\n",ans[i].y);
				fun(ans[i].x);
				anscount=1;
				flag++;
			}
			else if(ans[i-1].y==ans[i].y){
				if(anscount>0&&anscount%6<=5&&anscount%6>0){
					fprintf(fout," ");
					fun(ans[i].x); 
					anscount++;
				}
				else if(anscount%6==0){
					fprintf(fout,"\n");
					fun(ans[i].x);
					anscount++;
				}
			}
		}
		else break;
	}
	fprintf(fout,"\n");
	exit(0);
}


