/*
ID: huanshi
LANG: C++
TASK: inflate
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

int M,N; 
int dp[10010];
int max(int a,int b){
	return a>b?a:b;
} 
int main(){
	FILE *fin  = fopen ("inflate.in", "r");
    FILE *fout = fopen ("inflate.out", "w");
	fscanf(fin,"%d%d",&M,&N);
	int value,m;
	for(int i=0;i<N;i++){
		fscanf(fin,"%d%d",&value,&m);
		for(int j=1;j<=M;j++){
			if(j>=m){
				dp[j]=max(dp[j],dp[j-m]+value);	
			}
		} 
	}
	fprintf(fout,"%d\n",dp[M]);
	exit(0);
}


