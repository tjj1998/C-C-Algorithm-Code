/*
ID: huanshi
LANG: C++
TASK: heritage
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
char M[26];
int F[26],ccount=0;
int hash[26];
int bcount=0;
void bfs(int a,int b){
	if(a==b){
		fprintf(fout,"%c",M[a]);
		bcount++;
		return ;
	}
	else if(bcount<ccount){
		int temp=F[bcount];bcount++;
		if(temp>=a+1)
		bfs(a,temp-1);
		if(temp<=b-1)
		bfs(temp+1,b);
		fprintf(fout,"%c",M[temp]);
	}
}
int main(){
	fin  = fopen ("heritage.in", "r");
    fout = fopen ("heritage.out", "w");
	while(fscanf(fin,"%c",&M[ccount])!=EOF&&M[ccount]!='\n'){
		hash[M[ccount]-'A']=ccount;
		ccount++;
	}
	char temp;
	for(int i=0;i<ccount;i++){
		fscanf(fin,"%c",&temp);
		F[i]=hash[temp-'A'];	
	}
	bfs(0,ccount-1);
	fprintf(fout,"\n");
	exit(0);
}


