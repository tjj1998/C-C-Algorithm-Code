/*
ID: huanshi
LANG: C++
TASK: fence9
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int n,m,p,ans=0;
 
int main(){
	fin  = fopen ("fence9.in", "r");
    fout = fopen ("fence9.out", "w");
	fscanf(fin,"%d%d%d",&n,&m,&p);
	if(p>=n){
		for(int i=1;i<n;i++){
			ans+=m*i/n;
			if(m*i%n==0)ans--;		
		}
		for(int i=n;i<p;i++){
			if(i==0)continue;
			ans+=m*(p-i)/(p-n);
			if(m*(p-i)%(p-n)==0)ans--;
		}
	}else{
		for(int i=1;i<n;i++){
			ans+=m*i/n;
			if(m*i%n==0)ans--;
			if(i>=p)
			ans-=m*(i-p)/(n-p);		
		}
	}
	fprintf(fout,"%d\n",ans);
	exit(0);
}


