/*
ID: huanshi
LANG: C++
TASK: rockers
*/
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<algorithm>
#define INF 99999999
using namespace std;
FILE *fin,*fout;
int N,T,M;
int dp[25][25][25];//��i-j��k��CD���ɱ���ĸ����� 
int data[25];
int init(int a){
	int sum=T;
	priority_queue<int> q;
	q.push(0);
	for(int i=a;i<N;i++){
		if(sum>=data[i]){
			sum-=data[i];
			q.push(data[i]);
		}else if(data[i]<q.top()){
			sum=sum+(q.top()-data[i]);
			q.pop();
			q.push(data[i]);
		}
		dp[a][i][1]=q.size()-1;
	}
} 
int main(){
	fin  = fopen ("rockers.in", "r");
    fout = fopen ("rockers.out", "w");
	fscanf(fin,"%d%d%d",&N,&T,&M);
	for(int i=0;i<N;i++)
	fscanf(fin,"%d",&data[i]); 
	for(int i=0;i<N;i++){
		init(i); 
	}
	for(int k=2;k<=M;k++){
		for(int temp=0;temp<N;temp++)
			for(int i=0;i<N-temp;i++){
				int pro=i+temp;
				if(i==pro)dp[i][pro][k]=dp[i][pro][k-1];
				for(int j=i;j<pro;j++){
					dp[i][pro][k]=max(dp[i][pro][k],dp[i][j][k-1]+dp[j+1][pro][1]);
				}
			}
	}
	fprintf(fout,"%d\n",dp[0][N-1][M]);
	exit(0);
}


